# Project-Level Custom Subagent Registry

## Purpose

Enable project-specific customization of subagent selection. Teams can define custom subagents tailored to their project's needs, and the coordinator will automatically select the most appropriate subagent for each phase.

## Configuration File

### Location

**Project-level only**: `.claude/dev-workflow/subagents.yaml`

This file should be committed to git and shared with the entire team.

### Configuration Format

```yaml
# .claude/dev-workflow/subagents.yaml

# Custom subagents for this project
subagents:
  # Default subagent (fallback if no custom match)
  default:
    type: general-purpose
    description: Standard general-purpose subagent

  # Define custom subagents below
  frontend-dev:
    type: general-purpose
    description: Frontend development specialist
    triggers:
      keywords: [frontend, ui, component, react, vue, css, styling]
      file_patterns: ["src/components/**", "src/views/**", "*.tsx", "*.vue"]
      phase_patterns: [frontend, ui, component, interface]
    prompt_prefix: |
      You are a frontend development specialist for this project.
      Focus on clean component design, accessibility, and our styling conventions.

  backend-api:
    type: general-purpose
    description: Backend API development specialist
    triggers:
      keywords: [api, endpoint, route, controller, service, database]
      file_patterns: ["src/routes/**", "src/controllers/**", "src/services/**"]
      phase_patterns: [api, endpoint, backend, server]
    prompt_prefix: |
      You are a backend API specialist for this project.
      Follow our RESTful conventions and ensure proper error handling.

# Selection configuration
selection:
  strategy: best_match  # Options: best_match, first_match, explicit_only
  min_score: 0.5        # Minimum score (0.0-1.0) to use custom subagent
  allow_fallback: true  # Fall back to default if custom fails
```

## Selection Logic

### How It Works

When the coordinator needs to launch a subagent:

1. **Check for explicit assignment**
   - Look for `**Subagent**: subagent-name` in implementation plan
   - If found, use that subagent directly

2. **Load configuration** (if no explicit assignment)
   - Read `.claude/dev-workflow/subagents.yaml`
   - If file doesn't exist, use default `general-purpose`

3. **Analyze phase context**
   - Phase name and description
   - Files mentioned in phase scope
   - Keywords in phase instructions

4. **Score each custom subagent**
   - **Keyword match**: Phase contains trigger keywords? (40% weight)
   - **File pattern match**: Files match patterns? (30% weight)
   - **Phase pattern match**: Phase name matches patterns? (30% weight)

5. **Select best match**
   - If highest score >= `min_score`: Use that custom subagent
   - Otherwise: Use default subagent

6. **Launch with custom context**
   - Prepend `prompt_prefix` to phase instructions
   - Track subagent type used in scratchpad

### Selection Strategies

**best_match** (recommended):
```yaml
selection:
  strategy: best_match
  min_score: 0.5
```
Calculates score for all subagents, uses highest above threshold.

**first_match**:
```yaml
selection:
  strategy: first_match
```
Uses first subagent with any matching trigger (order matters).

**explicit_only**:
```yaml
selection:
  strategy: explicit_only
```
Only uses custom subagents when explicitly specified in implementation plan.

## Explicit Assignment

### In Implementation Plan

Explicitly assign subagents per phase:

```markdown
# wip/implementation_plan.md

## Phase 1: User Authentication API
**Subagent**: backend-api
**Files**: src/routes/auth.js, src/services/auth.js
**Description**: Implement JWT authentication endpoints

## Phase 2: Login UI Component
**Subagent**: frontend-dev
**Files**: src/components/Login.tsx
**Description**: Create responsive login form
```

The coordinator reads `**Subagent**: backend-api` and uses it directly.

### In Scratchpad Tracking

The coordinator records which subagent was used:

```markdown
## Active Work
**Phase:** Phase 1 - User Authentication API
**Subagent Type:** backend-api (custom)
**Started:** 2025-01-15 10:30
**Status:** in_progress
```

## Example Configurations

### Example 1: Full-Stack Web App

```yaml
# .claude/dev-workflow/subagents.yaml

subagents:
  default:
    type: general-purpose
    description: General development

  frontend-react:
    type: general-purpose
    description: React frontend specialist
    triggers:
      keywords: [react, component, jsx, tsx, hooks, frontend]
      file_patterns: ["src/components/**/*.tsx", "src/pages/**/*.tsx"]
      phase_patterns: [frontend, ui, component]
    prompt_prefix: |
      You are a React specialist for this project.
      - Use TypeScript with strict types
      - Follow our component structure: src/components/[Feature]/[Component].tsx
      - Use Tailwind CSS for styling
      - Implement proper error boundaries

  backend-express:
    type: general-purpose
    description: Express.js API specialist
    triggers:
      keywords: [api, endpoint, express, route, middleware]
      file_patterns: ["src/api/**/*.js", "src/routes/**/*.js"]
      phase_patterns: [api, backend, endpoint]
    prompt_prefix: |
      You are an Express.js API specialist for this project.
      - Follow RESTful conventions
      - Use async/await, not callbacks
      - Validate input with Joi schemas
      - Return consistent error format: {error: {message, code}}

  database-postgres:
    type: general-purpose
    description: PostgreSQL database specialist
    triggers:
      keywords: [database, postgres, sql, migration, schema]
      file_patterns: ["src/db/**/*.js", "migrations/**/*.sql"]
      phase_patterns: [database, migration, schema]
    prompt_prefix: |
      You are a PostgreSQL specialist for this project.
      - Write migrations in src/db/migrations/
      - Use parameterized queries (never string concat)
      - Add proper indexes for foreign keys
      - Include rollback logic in migrations

selection:
  strategy: best_match
  min_score: 0.6
  allow_fallback: true
```

### Example 2: Data Science Project

```yaml
# .claude/dev-workflow/subagents.yaml

subagents:
  default:
    type: general-purpose
    description: General Python development

  ml-modeling:
    type: general-purpose
    description: ML model development specialist
    triggers:
      keywords: [model, train, sklearn, tensorflow, prediction, ml]
      file_patterns: ["src/models/**/*.py", "notebooks/*_model.ipynb"]
      phase_patterns: [model, training, prediction]
    prompt_prefix: |
      You are an ML specialist for this project.
      - Save models to models/ directory
      - Track experiments with MLflow
      - Include model evaluation metrics
      - Use cross-validation for model selection

  data-pipeline:
    type: general-purpose
    description: ETL pipeline specialist
    triggers:
      keywords: [pipeline, etl, transform, ingest, data]
      file_patterns: ["src/pipelines/**/*.py", "src/etl/**/*.py"]
      phase_patterns: [pipeline, etl, ingestion]
    prompt_prefix: |
      You are a data pipeline specialist for this project.
      - Use Apache Airflow DAGs
      - Implement idempotent operations
      - Log data quality metrics
      - Handle partial failures gracefully

selection:
  strategy: best_match
  min_score: 0.5
  allow_fallback: true
```

### Example 3: Microservices

```yaml
# .claude/dev-workflow/subagents.yaml

subagents:
  default:
    type: general-purpose
    description: General microservice development

  service-api:
    type: general-purpose
    description: Microservice API specialist
    triggers:
      keywords: [service, grpc, protobuf, rpc, microservice]
      file_patterns: ["services/**/api/**", "proto/**/*.proto"]
      phase_patterns: [service, api, grpc]
    prompt_prefix: |
      You are a microservices specialist for this project.
      - Define APIs in proto/ directory
      - Implement health checks
      - Add distributed tracing
      - Version APIs explicitly

  messaging:
    type: general-purpose
    description: Event-driven messaging specialist
    triggers:
      keywords: [kafka, event, message, queue, pubsub]
      file_patterns: ["services/**/consumers/**", "services/**/producers/**"]
      phase_patterns: [messaging, event, kafka]
    prompt_prefix: |
      You are a messaging specialist for this project.
      - Use Avro schemas for events
      - Implement idempotent consumers
      - Add dead letter queue handling
      - Include message tracing headers

selection:
  strategy: best_match
  min_score: 0.5
  allow_fallback: true
```

## Integration with Coordinator

### Updated Coordinator Workflow

```markdown
When launching subagent for a phase:

1. Check implementation plan for explicit **Subagent**: assignment
2. If explicit: Use that subagent
3. If not explicit:
   a. Check if .claude/dev-workflow/subagents.yaml exists
   b. If not exists: Use default general-purpose
   c. If exists:
      - Parse configuration
      - Extract phase context (keywords, files, name)
      - Score each custom subagent
      - Select best match >= min_score
      - Fall back to default if no good match
4. Construct launch prompt:
   - Include prompt_prefix (if custom subagent)
   - Add phase-specific instructions
   - Specify deliverables and scope
5. Launch via Task tool with subagent_type
6. Record subagent type in scratchpad
```

## Setup Guide

### Step 1: Create Configuration Directory

```bash
mkdir -p .claude/dev-workflow
```

### Step 2: Create Configuration File

```bash
cat > .claude/dev-workflow/subagents.yaml << 'EOF'
subagents:
  default:
    type: general-purpose
    description: General development

  # Add your custom subagents here

selection:
  strategy: best_match
  min_score: 0.5
  allow_fallback: true
EOF
```

### Step 3: Define Custom Subagents

Add subagents based on your project needs (see examples above).

### Step 4: Test

Create a test implementation plan and verify correct subagents are selected.

### Step 5: Commit to Git

```bash
git add .claude/dev-workflow/subagents.yaml
git commit -m "Add custom subagent configuration"
```

## Coordinator Implementation

### Reading Configuration

```python
# Pseudo-code for coordinator logic

def select_subagent(phase):
    # Check for explicit assignment
    if phase.has_explicit_subagent():
        return phase.subagent_name

    # Load config
    config_path = ".claude/dev-workflow/subagents.yaml"
    if not file_exists(config_path):
        return "general-purpose"  # default

    config = parse_yaml(config_path)

    # Extract phase context
    context = {
        'keywords': extract_keywords(phase.description),
        'files': phase.files,
        'phase_name': phase.name
    }

    # Score subagents
    scores = {}
    for name, subagent in config['subagents'].items():
        if name == 'default':
            continue
        scores[name] = calculate_score(subagent, context)

    # Select best match
    strategy = config['selection']['strategy']
    min_score = config['selection']['min_score']

    if strategy == 'best_match':
        best = max(scores, key=scores.get)
        if scores[best] >= min_score:
            return best

    # Fallback to default
    return config['subagents']['default']['type']

def calculate_score(subagent, context):
    keyword_score = match_keywords(
        subagent['triggers']['keywords'],
        context['keywords']
    ) * 0.4

    file_score = match_patterns(
        subagent['triggers']['file_patterns'],
        context['files']
    ) * 0.3

    phase_score = match_patterns(
        subagent['triggers']['phase_patterns'],
        [context['phase_name']]
    ) * 0.3

    return keyword_score + file_score + phase_score
```

## Benefits

✅ **Team Alignment**: Shared configuration ensures consistent specialization
✅ **Project-Specific**: Tailored to your architecture and conventions
✅ **Automatic**: Coordinator selects appropriate subagent based on context
✅ **Explicit Override**: Can specify exact subagent when needed
✅ **Version Controlled**: Configuration evolves with project
✅ **No Breaking Changes**: Optional—works without configuration

## Best Practices

1. **Start with 2-3 subagents** for clear specializations
2. **Test triggers** with real phases to verify selection
3. **Document rationale** in comments within YAML
4. **Keep prompt_prefix focused** on project-specific conventions
5. **Commit configuration** to git for team sharing
6. **Review and refine** based on usage patterns
7. **Use explicit assignment** for critical phases

## Troubleshooting

**Subagent not selected when expected?**
- Check trigger keywords match phase description
- Lower `min_score` threshold
- Add more specific keywords
- Use explicit assignment

**Wrong subagent selected?**
- Make triggers more specific
- Raise `min_score` threshold
- Check file patterns match actual paths

**Configuration not loading?**
- Verify path: `.claude/dev-workflow/subagents.yaml`
- Validate YAML syntax
- Check file is readable
