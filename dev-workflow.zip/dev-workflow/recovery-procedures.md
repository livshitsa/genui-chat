# Recovery Procedures

## Purpose

Development work is often interrupted. This guide ensures you can **resume seamlessly** from any interruption point by following the scratchpad-driven recovery process.

## Common Interruption Scenarios

- Session timeout or connection loss
- User returns after hours/days
- Context switch to different task
- Error/crash during implementation
- User explicitly pauses work

## Recovery Process

### Step 1: Read Scratchpad First

**ALWAYS** start with:
```bash
cat wip/scratchpad.md
```

**Never** assume where you left off. Always read the scratchpad to know:
- What was being worked on?
- What's completed?
- What's in progress?
- Any blockers?
- What's next?

### Step 2: Assess Current State

From the scratchpad, determine:

#### A. Was work in progress?
Check "Active Work" section:
- Status: `in_progress` → Subagent may have been working
- Status: `blocked` → Blocker needs resolution
- Status: `completed` → Phase done, ready for next

#### B. What's the last completed step?
Check "Completed Steps" section:
- Last timestamp shows when work stopped
- Last phase completed shows progress point

#### C. Are there blockers?
Check "Blockers/Issues" section:
- Active blockers need resolution before continuing
- May need user input to unblock

#### D. What are next steps?
Check "Next Steps" section:
- Should list specific next actions
- Follow these to resume work

### Step 3: Determine Recovery Action

Based on assessment, take appropriate action:

#### Scenario A: Phase In Progress

**Scratchpad shows:**
```markdown
**Current Phase:** Phase 3 - Product Catalog
**Status:** in_progress
```

**Recovery action:**
1. Check if subagent completed work (may have finished but not updated)
2. If incomplete, relaunch subagent for same phase
3. Once complete, update scratchpad
4. Proceed to next phase

#### Scenario B: Phase Completed, Next Pending

**Scratchpad shows:**
```markdown
**Current Phase:** Phase 3 - Product Catalog
**Status:** completed

Next Steps:
1. Launch Phase 4 - Shopping Cart
```

**Recovery action:**
1. Verify Phase 3 truly completed (check files, tests)
2. Launch Phase 4 as indicated
3. Update scratchpad with new active work

#### Scenario C: Blocked

**Scratchpad shows:**
```markdown
**Status:** blocked

Blockers/Issues:
- Need Stripe API keys from user
```

**Recovery action:**
1. Check if blocker can be resolved
2. If needs user input, ask user
3. If can work around, launch alternative phase
4. Update scratchpad once unblocked

#### Scenario D: Clean State (No Active Work)

**Scratchpad shows:**
```markdown
**Status:** not_started
```

**Recovery action:**
1. Read implementation plan if exists
2. Start Phase 1
3. Initialize scratchpad properly

### Step 4: Resume Work

Once you know the state, resume:

1. **Update scratchpad** with recovery timestamp
2. **Launch appropriate subagent** for next phase
3. **Track progress** as normal
4. **Update scratchpad** after completion

### Step 5: Verify Continuity

Before proceeding, ensure:
- [ ] Read and understood scratchpad
- [ ] Know what was last completed
- [ ] Know what's next
- [ ] Any blockers identified
- [ ] Scratchpad updated with recovery action

## Recovery Examples

### Example 1: Mid-Phase Recovery

**Context:** User returns after 2 days, unclear where work stopped.

**Step 1: Read scratchpad**
```markdown
# Implementation Progress Scratchpad

Last Updated: 2025-01-13 15:30
Current Phase: Phase 3 - Product Catalog
Status: in_progress

Active Work:
Phase: Phase 3 - Product Catalog
Subagent: Implementing product CRUD endpoints
Started: 2025-01-13 15:20
Status: in_progress

Completed Steps:
1. [2025-01-13 10:00] Phase 1: Setup ✓
2. [2025-01-13 14:00] Phase 2: Authentication ✓

Next Steps:
1. Complete Phase 3 product endpoints
2. Launch Phase 4 shopping cart
```

**Step 2: Assess**
- Phase 3 was in progress
- Started 2 days ago but incomplete
- Next step is to complete Phase 3

**Step 3: Recovery Action**
```markdown
You (recovering):
"I see Phase 3 was in progress but likely incomplete. Let me check
what files exist and relaunch Phase 3 to complete it."

Check:
ls src/routes/products.js  # Does file exist?
cat src/routes/products.js  # How complete is it?

If incomplete:
Launch new subagent for Phase 3 with same instructions
```

**Step 4: Resume**
```markdown
Update scratchpad:

Last Updated: 2025-01-15 09:15  # NEW
Current Phase: Phase 3 - Product Catalog
Status: in_progress

Active Work:
Phase: Phase 3 - Product Catalog
Subagent: Relaunching product endpoints implementation
Started: 2025-01-15 09:15  # NEW
Status: in_progress

Notes:
- Recovering from 2-day interruption
- Phase 3 was incomplete, relaunching implementation
```

Launch subagent, complete phase, update scratchpad.

### Example 2: Between-Phase Recovery

**Context:** User ended session after completing phase, returning to continue.

**Step 1: Read scratchpad**
```markdown
Last Updated: 2025-01-14 17:00
Current Phase: Phase 4 - Shopping Cart
Status: completed

Completed Steps:
1. [2025-01-14 10:00] Phase 1: Setup ✓
2. [2025-01-14 12:00] Phase 2: Authentication ✓
3. [2025-01-14 14:30] Phase 3: Product Catalog ✓
4. [2025-01-14 17:00] Phase 4: Shopping Cart ✓

Next Steps:
1. Launch Phase 5 - Checkout Flow
2. Implement payment integration
```

**Step 2: Assess**
- Phase 4 completed yesterday
- Next step clear: Launch Phase 5
- No blockers

**Step 3: Recovery Action**
```markdown
You (recovering):
"Phase 4 completed yesterday. Ready to start Phase 5 - Checkout Flow."
```

**Step 4: Resume**
```markdown
Update scratchpad:

Last Updated: 2025-01-15 09:30  # NEW
Current Phase: Phase 5 - Checkout Flow  # NEW
Status: in_progress  # NEW

Active Work:
Phase: Phase 5 - Checkout Flow
Subagent: Launching checkout implementation
Started: 2025-01-15 09:30
Status: in_progress
```

Launch Phase 5 subagent.

### Example 3: Blocked Recovery

**Context:** Work blocked on external dependency, user returns with solution.

**Step 1: Read scratchpad**
```markdown
Last Updated: 2025-01-14 16:00
Current Phase: Phase 5 - Checkout Flow
Status: blocked

Active Work:
Phase: Phase 5 - Checkout Flow
Status: blocked

Blockers/Issues:
Active Blockers:
- Payment integration needs Stripe API keys
- Waiting for user to provide credentials

Next Steps:
1. BLOCKED: Waiting for Stripe API keys
2. Once unblocked: Complete payment integration
```

**Step 2: Assess**
- Blocked on Stripe API keys
- Need to ask user if they have them now

**Step 3: Recovery Action**
```markdown
You (recovering):
"I see work was blocked on Stripe API keys. Do you have the
credentials now? I'll need:
- Stripe publishable key
- Stripe secret key

Once provided, I can resume Phase 5 payment integration."

User provides keys.

You:
"Great! Unblocking and resuming Phase 5."
```

**Step 4: Resume**
```markdown
Update scratchpad:

Last Updated: 2025-01-15 10:00  # NEW
Current Phase: Phase 5 - Checkout Flow
Status: in_progress  # UNBLOCKED

Active Work:
Phase: Phase 5 - Checkout Flow
Subagent: Resuming payment integration with provided credentials
Started: 2025-01-15 10:00
Status: in_progress

Blockers/Issues:
Resolved Blockers:
- [2025-01-15] Stripe API keys provided by user

Next Steps:
1. Complete payment integration
2. Test checkout flow
3. Final integration testing
```

Launch subagent with Stripe credentials, complete phase.

## Critical Recovery Rules

### 1. Never Guess State
- ❌ "I think we were working on authentication"
- ✅ Read scratchpad to know exactly what was happening

### 2. Always Update Scratchpad on Recovery
```markdown
Last Updated: [NEW TIMESTAMP]

Notes:
- Recovered from interruption at [TIME]
- Resuming [PHASE] work
```

### 3. Verify Before Proceeding
```bash
# Check what files exist
ls src/

# Verify tests pass for completed phases
npm test

# Ensure environment setup intact
cat .env
```

### 4. Handle Ambiguous State

If scratchpad unclear or outdated:
1. Investigate actual codebase state
2. Run tests to see what works
3. Update scratchpad to reflect reality
4. Proceed from verified state

### 5. Communicate Recovery to User

```markdown
"I've read the scratchpad and see we were working on Phase 3 - Product
Catalog. It appears incomplete. I'll relaunch implementation to complete
this phase, then proceed to Phase 4."
```

User appreciates transparency about recovery process.

## Scratchpad-First Recovery Checklist

Before resuming any work:

- [ ] Read `wip/scratchpad.md` completely
- [ ] Understand last completed phase
- [ ] Identify current/next phase
- [ ] Check for any blockers
- [ ] Verify what files exist vs what scratchpad says
- [ ] Update scratchpad with recovery timestamp
- [ ] Launch appropriate next action
- [ ] Continue tracking in scratchpad

## When Scratchpad Missing

If `wip/scratchpad.md` doesn't exist:

1. **Check for implementation plan:**
   ```bash
   cat wip/implementation_plan.md
   ```

2. **Investigate codebase state:**
   ```bash
   ls -la src/
   git log --oneline -10
   npm test
   ```

3. **Create scratchpad from current state:**
   - Determine what's implemented by reading code
   - Create scratchpad reflecting current reality
   - Proceed from there

4. **Ask user if unclear:**
   "I don't see a scratchpad. What's the current state of this project?
   What should I work on next?"

## Recovery Anti-Patterns

❌ **Don't:**
- Start coding without reading scratchpad
- Assume you know where work stopped
- Skip updating scratchpad on recovery
- Ignore blockers listed in scratchpad
- Duplicate work already completed

✅ **Do:**
- Always read scratchpad first
- Update scratchpad on recovery
- Verify state matches scratchpad
- Address blockers before proceeding
- Continue from documented state

## Key Principle

> **The scratchpad is your memory across sessions.**
>
> Trust it. Maintain it. Use it.

If scratchpad says Phase 3 is done, it's done.
If scratchpad says Phase 4 is blocked, it's blocked.
If scratchpad says next step is X, do X.

Recovery is simple when you follow the scratchpad.
