---
name: dev-workflow
description: Scratchpad-driven development workflow using coordinator-implementer pattern with progress tracking. Orchestrates complex multi-step feature implementations by delegating focused phases to subagents while maintaining progress in wip/scratchpad.md. Use when users request complex multi-step features, mention "resume development", "workflow", or "coordination", or when project contains wip/scratchpad.md or wip/implementation_plan.md files. Enables recovery from interruptions by tracking current phase, completed steps, and next actions.
allowed-tools: Read(*), Write(*), Task(*), TodoWrite(*), Bash(*), Grep(*), Glob(*)
---

# Development Workflow Skill

## Overview

This skill implements a **two-tier agent architecture** for managing complex development projects:

1. **Main Agent (Coordinator)**: Orchestrates work, tracks progress, delegates phases
2. **Subagents (Implementers)**: Execute focused implementation tasks

### Key Files
- `wip/implementation_plan.md` - Full implementation plan (READ-ONLY reference)
- `wip/scratchpad.md` - Active progress tracking (main agent READ-WRITE)

## When This Skill Activates

Claude automatically uses this skill when:
- User requests implementation of complex multi-step features
- Project contains `wip/scratchpad.md` or `wip/implementation_plan.md`
- User asks to "resume development" or "continue implementation"
- User mentions "workflow", "coordination", or "delegate to subagents"
- Task requires breaking down into multiple implementation phases

## Workflow Overview

### For Main Agent (You as Coordinator)

1. **Read current progress**
   - Always check `wip/scratchpad.md` first
   - Understand what's completed and what's next

2. **Determine next phase**
   - Break work into focused, manageable chunks
   - Each subagent should handle one clear phase

3. **Launch subagent**
   - Use Task tool with clear phase instructions
   - Provide specific scope and deliverables

4. **Update scratchpad**
   - Record completion after each phase
   - Update status, timestamps, files modified

5. **Never implement directly**
   - Always delegate to subagents
   - Your role is coordination, not implementation

### For Subagents (When You're the Implementer)

See `implementer-guide.md` for detailed instructions.

## Quick Start

### Starting New Workflow
1. Create wip/scratchpad.md using template from scratchpad-template.md
2. Create wip/implementation_plan.md with full project plan
3. Begin Phase 1 by launching subagent
4. Update scratchpad after each completion

### Resuming Existing Workflow
1. Read wip/scratchpad.md
2. Check "Current Status" and "Active Work" sections
3. Identify next pending phase
4. Launch subagent for that phase
5. Update scratchpad when complete

## Project Customization

### Custom Subagent Selection

Projects can define **custom subagents** specialized for their architecture:

**Configuration File**: `.claude/dev-workflow/subagents.yaml`

Example custom subagents:
- `frontend-dev` - React/Vue specialist with project conventions
- `backend-api` - API development with your REST patterns
- `database` - Schema and migration specialist
- `testing` - QA with your testing framework

**How it works:**
1. Coordinator reads phase context (keywords, files, name)
2. Scores available custom subagents based on triggers
3. Selects best match above threshold
4. Launches with project-specific `prompt_prefix`
5. Falls back to default if no good match

**See `subagent-registry.md` for complete guide**
**See `subagents.example.yaml` for configuration template**

## Detailed Guides

- **Coordinator Role**: See `coordinator-guide.md`
- **Implementer Role**: See `implementer-guide.md`
- **Scratchpad Format**: See `scratchpad-template.md`
- **Recovery Procedures**: See `recovery-procedures.md`
- **Custom Subagents**: See `subagent-registry.md`

## Success Criteria

A successful workflow execution includes:
- ✅ Scratchpad maintained with current status
- ✅ Each phase completed by focused subagent
- ✅ Progress tracked with timestamps
- ✅ Files created/modified documented
- ✅ Tests run for implemented code
- ✅ Blockers identified and addressed
