# Scratchpad Format and Maintenance

## Purpose

The scratchpad (`wip/scratchpad.md`) is the **single source of truth** for active development progress. It enables:
- Tracking current state across sessions
- Recovery from interruptions
- Visibility into what's done and what's next
- Coordination between main agent and user

## File Location

```
wip/scratchpad.md
```

**Ownership:**
- Main agent (coordinator): READ and WRITE
- Subagents (implementers): No access - report to main agent instead
- User: READ to understand progress

## Template

```markdown
# Implementation Progress Scratchpad

**Last Updated:** [YYYY-MM-DD HH:MM]
**Current Phase:** [Phase name/number]
**Status:** [not_started|in_progress|blocked|completed]

## Current Status

- [ ] Phase 1: [Description]
- [ ] Phase 2: [Description]
- [ ] Phase 3: [Description]
- [ ] Phase 4: [Description]
- [ ] Phase N: [Description]

## Active Work

**Phase:** [Current phase name/number]
**Started:** [YYYY-MM-DD HH:MM]
**Status:** [in_progress|blocked|completed]

**What's being done:**
[Brief description of current implementation work]

## Completed Steps

1. [YYYY-MM-DD HH:MM] Phase 1: [Description] ✓
   - Files: `path/to/file1.js`, `path/to/file2.js`
   - Tests: All passing
   - Notes: [Any important notes]

2. [YYYY-MM-DD HH:MM] Phase 2: [Description] ✓
   - Files: `path/to/file3.js`
   - Tests: 15 tests added, all passing
   - Notes: [Any important notes]

## Files Created/Modified This Session

### Created
- `src/routes/auth.js` - Authentication route handlers
- `src/middleware/auth.js` - JWT verification middleware
- `tests/auth.test.js` - Authentication tests

### Modified
- `src/app.js` - Added auth routes
- `package.json` - Added bcrypt dependency
- `.env.example` - Added JWT_SECRET variable

## Blockers/Issues

### Active Blockers
- [Issue description if any]
- [What's needed to resolve]

### Resolved Blockers
- [YYYY-MM-DD] [Issue] - [How it was resolved]

## Next Steps

1. [Next immediate action - specific phase to launch]
2. [Following action]
3. [Subsequent action]

## Notes

- [Any important context for future sessions]
- [Decisions made and rationale]
- [Recommendations for remaining work]
```

## Field Descriptions

### Header Section

**Last Updated:**
- Update timestamp every time you modify scratchpad
- Format: `YYYY-MM-DD HH:MM`
- Use: Know when last coordination happened

**Current Phase:**
- Which phase is currently being worked on
- Should match active work section
- Use: Quick reference to current focus

**Status:**
- `not_started` - Work hasn't begun
- `in_progress` - Subagent actively working
- `blocked` - Stuck on something, can't proceed
- `completed` - All phases done

### Current Status Section

**Purpose:** High-level overview of all phases

- Use checkboxes: `- [ ]` for pending, `- [x]` for complete
- List all planned phases
- Update checkboxes as phases complete
- Enables quick progress visualization

### Active Work Section

**Purpose:** Details about current in-flight work

**Phase:** Name/number of phase currently being worked on

**Started:** When this phase began

**Status:**
- `in_progress` - Subagent working
- `blocked` - Hit a blocker
- `completed` - Ready to move to next

**What's being done:** 1-2 sentence description of current work

### Completed Steps Section

**Purpose:** Historical record of finished work

**Format:**
```markdown
[Timestamp] Phase X: [Description] ✓
- Files: [List of files created/modified]
- Tests: [Test results]
- Notes: [Important information]
```

**When to add:**
- After each phase completes
- Include timestamp for tracking
- List all files touched
- Record test results
- Note any important decisions or issues

### Files Created/Modified Section

**Purpose:** Track all filesystem changes this session

**Created:**
- List new files with brief description
- Full path from project root
- What the file does

**Modified:**
- Existing files that were changed
- What changed in each file

**Use cases:**
- User wants to know what was touched
- Recovery - what needs review after interruption
- Preparation for commits/PRs

### Blockers/Issues Section

**Purpose:** Track impediments and their resolution

**Active Blockers:**
- Current blockers preventing progress
- What's needed to resolve
- Who/what can unblock

**Resolved Blockers:**
- Historical record of past blockers
- How they were resolved
- Learning for future

### Next Steps Section

**Purpose:** Clear action items for resuming work

- List specific, actionable next steps
- Order by priority
- Be specific: "Launch subagent for Phase 4: Product endpoints"
- Not vague: "Continue work"

### Notes Section

**Purpose:** Capture important context

- Design decisions made
- Rationale for approach
- Recommendations for future
- Anything important to remember

## Maintenance Guidelines

### When to Update

**Always update after:**
- Subagent completes a phase
- Blocker is encountered
- Blocker is resolved
- Starting new phase
- Session ends (if interrupted mid-phase)

### How to Update

1. **Update timestamp** in header
2. **Update current phase** if changed
3. **Update current status** checkboxes
4. **Update active work** section with current state
5. **Add completed step** if phase finished
6. **Update files** section with new changes
7. **Update blockers** if any encountered/resolved
8. **Update next steps** with new plan

### Update Frequency

- Minimum: After each phase completion
- Ideal: Any time state changes significantly
- Never: Skip updates (always maintain current state)

## Examples

### Example 1: Starting New Project

```markdown
# Implementation Progress Scratchpad

**Last Updated:** 2025-01-15 10:30
**Current Phase:** Phase 1 - Project Setup
**Status:** in_progress

## Current Status

- [ ] Phase 1: Project setup and scaffolding
- [ ] Phase 2: User authentication
- [ ] Phase 3: Product catalog
- [ ] Phase 4: Shopping cart
- [ ] Phase 5: Checkout flow

## Active Work

**Phase:** Phase 1 - Project Setup
**Started:** 2025-01-15 10:25
**Status:** in_progress

**What's being done:**
Setting up Express.js project structure, installing dependencies, configuring database connection.

## Completed Steps

None yet - just started.

## Files Created/Modified This Session

None yet.

## Blockers/Issues

None currently.

## Next Steps

1. Wait for Phase 1 subagent to complete setup
2. Launch Phase 2 for authentication implementation
3. Then proceed to product catalog

## Notes

- User wants JWT-based authentication
- Using PostgreSQL for database
- Targeting REST API architecture
```

### Example 2: Mid-Project State

```markdown
# Implementation Progress Scratchpad

**Last Updated:** 2025-01-15 15:45
**Current Phase:** Phase 4 - Shopping Cart
**Status:** in_progress

## Current Status

- [x] Phase 1: Project setup and scaffolding
- [x] Phase 2: User authentication
- [x] Phase 3: Product catalog
- [ ] Phase 4: Shopping cart
- [ ] Phase 5: Checkout flow

## Active Work

**Phase:** Phase 4 - Shopping Cart
**Started:** 2025-01-15 15:30
**Status:** in_progress

**What's being done:**
Building shopping cart endpoints (add, remove, update quantity) and cart state persistence.

## Completed Steps

1. [2025-01-15 10:45] Phase 1: Project setup ✓
   - Files: `package.json`, `src/app.js`, `src/db/connection.js`
   - Tests: Basic server test passing
   - Notes: PostgreSQL configured, server running on port 3000

2. [2025-01-15 12:30] Phase 2: User authentication ✓
   - Files: `src/routes/auth.js`, `src/middleware/auth.js`, `tests/auth.test.js`
   - Tests: 8 tests added, all passing
   - Notes: JWT-based auth working, tokens expire in 24h

3. [2025-01-15 14:15] Phase 3: Product catalog ✓
   - Files: `src/routes/products.js`, `src/models/Product.js`, `tests/products.test.js`
   - Tests: 12 tests added, all passing
   - Notes: CRUD operations complete, pagination added

## Files Created/Modified This Session

### Created
- `src/routes/auth.js` - Authentication endpoints
- `src/routes/products.js` - Product CRUD endpoints
- `src/middleware/auth.js` - JWT verification
- `src/models/Product.js` - Product database model
- `tests/auth.test.js` - Auth tests (8 tests)
- `tests/products.test.js` - Product tests (12 tests)

### Modified
- `src/app.js` - Added auth and product routes
- `package.json` - Added bcrypt, jsonwebtoken
- `.env.example` - Added JWT_SECRET, DB connection vars

## Blockers/Issues

### Active Blockers
None currently.

### Resolved Blockers
- [2025-01-15 12:15] Missing bcrypt dependency - Resolved: Added to package.json

## Next Steps

1. Wait for Phase 4 (shopping cart) to complete
2. Launch Phase 5 for checkout flow implementation
3. Final integration testing across all modules

## Notes

- User prefers session-based cart over cookie-based
- Cart should persist to database for logged-in users
- Guest carts stored in session only
- All tests passing so far, good progress
```

### Example 3: Blocked State

```markdown
# Implementation Progress Scratchpad

**Last Updated:** 2025-01-15 16:20
**Current Phase:** Phase 5 - Checkout Flow
**Status:** blocked

## Current Status

- [x] Phase 1: Project setup and scaffolding
- [x] Phase 2: User authentication
- [x] Phase 3: Product catalog
- [x] Phase 4: Shopping cart
- [ ] Phase 5: Checkout flow

## Active Work

**Phase:** Phase 5 - Checkout Flow
**Started:** 2025-01-15 16:00
**Status:** blocked

**What's being done:**
Attempted to implement Stripe payment integration but blocked on missing API keys.

## Completed Steps

[Previous phases 1-4 listed here...]

4. [2025-01-15 15:55] Phase 4: Shopping cart ✓
   - Files: `src/routes/cart.js`, `src/models/Cart.js`, `tests/cart.test.js`
   - Tests: 10 tests added, all passing
   - Notes: Cart persistence working for both logged-in and guest users

## Files Created/Modified This Session

[All previous files...]

## Blockers/Issues

### Active Blockers
- **Payment Integration Blocked:** Need Stripe API keys (publishable and secret)
  - Required in: `.env` file
  - Action needed: User must provide Stripe credentials
  - Blocker since: 2025-01-15 16:15
  - Impact: Cannot test payment processing

### Resolved Blockers
- [2025-01-15 12:15] Missing bcrypt dependency - Resolved: Added to package.json

## Next Steps

1. **BLOCKED:** Waiting for user to provide Stripe API keys
2. Once unblocked: Complete Phase 5 payment integration
3. Add order confirmation email functionality
4. Final integration testing

## Notes

- All modules except payment working correctly
- Can proceed with non-payment parts of checkout while blocked
- Consider implementing order creation first, payment later
```

## Key Principles

1. **Always current** - Update immediately when state changes
2. **Comprehensive** - Track all important details
3. **Actionable** - Next steps should be clear
4. **Timestamped** - Know when things happened
5. **Honest** - Reflect actual state, including blockers

## Benefits

- **Continuity:** Resume work seamlessly after interruptions
- **Transparency:** User sees exactly what's happening
- **Coordination:** Main agent knows exactly where things stand
- **Recovery:** Can recover from any interruption point
- **Documentation:** Historical record of implementation

Maintain this scratchpad religiously, and your workflow will be robust and recoverable.
