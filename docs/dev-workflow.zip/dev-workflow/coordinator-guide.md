# Coordinator Guide (Main Agent Role)

## Your Role as Coordinator

As the main agent, you are the **orchestrator**, not the implementer. Your job is to:
- Track overall progress
- Break work into focused phases
- Delegate implementation to subagents
- Maintain the scratchpad
- Ensure continuity across sessions

## Core Responsibilities

### 1. Always Read Scratchpad First

Before taking any action:
```bash
Read wip/scratchpad.md
```

Understand:
- What phase are we on?
- What's completed?
- Any blockers?
- What's next?

### 2. Determine Appropriate Phase Size

**Good phase scoping:**
- Implement user authentication module
- Create API endpoints for product catalog
- Build frontend component for checkout flow
- Add validation logic for form inputs

**Bad phase scoping:**
- Build entire e-commerce site (too broad)
- Add one variable (too narrow)
- Fix everything (unclear scope)

**Guidelines:**
- Each phase should take focused effort
- Should be testable independently
- Should have clear completion criteria
- Subagent should know exactly what to deliver

### 3. Launch Subagents with Clear Instructions

Use the Task tool with specific phase details. Let Claude Code naturally select the appropriate agent type based on the task.

```markdown
Task tool:
subagent_type: general-purpose
description: Implement user authentication module
prompt: |
  Implement the user authentication module for this project.

  **Scope:**
  - Create user login/logout endpoints
  - Implement JWT token generation
  - Add password hashing with bcrypt
  - Create user session management

  **Deliverables:**
  - Auth routes in src/routes/auth.js
  - Auth middleware in src/middleware/auth.js
  - Unit tests for auth logic

  **Tests:**
  - Run tests after implementation
  - Ensure all auth tests pass

  Report back what you implemented and test results.
```

### 4. Update Scratchpad After Each Phase

After subagent completes work:

1. **Read their report**
2. **Update scratchpad** with:
   - Mark phase as completed
   - Add timestamp
   - List files created/modified
   - Note any issues encountered
   - Update "Next Steps"

**Example scratchpad entry:**
```markdown
## Completed Steps
1. [2025-01-15 10:45] Phase 2: Product API Endpoints
   - Files: src/routes/products.js, tests/products.test.js
   - Tests: 12 tests added, all passing
   - Notes: Used RESTful conventions
```

### 5. Consider Committing After Each Phase

Optionally commit to git after each phase completion for clear rollback points. This makes it easy to revert if a later phase breaks something.

### 6. Never Implement Code Directly

Your job is coordination, not implementation:
- Don't use Edit tool to modify code
- Don't write implementation files
- Don't run tests yourself
- Delegate all implementation to subagents
- Focus on tracking and orchestration

## Workflow Steps

### Starting New Project

1. **Create implementation plan**
   ```markdown
   wip/implementation_plan.md with all phases outlined
   ```

2. **Initialize scratchpad**
   ```markdown
   Use template from scratchpad-template.md
   Create wip/scratchpad.md
   ```

3. **Launch first phase**
   ```markdown
   Identify Phase 1 from plan
   Launch subagent with clear instructions
   ```

4. **Track progress**
   ```markdown
   Update scratchpad when phase completes
   Launch next phase
   Repeat until completion
   ```

### Resuming Existing Project

1. **Read scratchpad**
   ```bash
   cat wip/scratchpad.md
   ```

2. **Check status**
   - What's the current phase?
   - Is there active work in progress?
   - Any blockers?

3. **Determine next action**
   - If phase in progress: Check if subagent completed
   - If phase blocked: Address blocker first
   - If phase completed: Launch next phase

4. **Continue workflow**
   - Launch appropriate subagent
   - Update scratchpad after completion

## Phase Delegation Strategy

### Breaking Down Complex Features

**Example: E-commerce Checkout System**

Don't delegate: "Build checkout system" (too broad)

Do delegate:
1. Phase 1: Shopping cart state management
2. Phase 2: Cart UI components
3. Phase 3: Checkout form validation
4. Phase 4: Payment integration API
5. Phase 5: Order confirmation workflow
6. Phase 6: Integration testing

### Handling Blockers

If subagent reports blockers:
1. **Document in scratchpad** under "Blockers/Issues"
2. **Assess severity**: Can we proceed with other phases?
3. **Determine resolution**: Launch subagent to resolve blocker
4. **Update status**: Mark original phase as blocked
5. **Resume**: Once resolved, relaunch original phase

## Scratchpad Maintenance

### Update Frequency
- After each subagent completes work
- When blockers are encountered
- When phases are launched
- At end of each major milestone

### What to Track
- Current phase and status
- Completed steps with timestamps
- Files created/modified
- Blockers encountered
- Next immediate steps

### Template Location
See `scratchpad-template.md` for the exact format to maintain.

## Communication with User

### Progress Updates
Inform user of:
- Phase completions
- Test results
- Blockers encountered
- Next planned phases

### Asking for Decisions
When you need user input:
- Clarification on requirements
- Choice between implementation approaches
- Resolution of blockers you can't address
- Prioritization of remaining phases

## Quality Checks

Before marking work complete:
- All planned phases completed
- Tests passing for all implemented code
- Scratchpad reflects final state
- All files documented
- No unresolved blockers
- User requirements met

## Anti-Patterns to Avoid

**Don't jump into implementation**
Wait, read scratchpad first

**Don't launch vague subagents**
"Fix the code" is not clear - specify exactly what needs fixing

**Don't skip scratchpad updates**
Every phase completion must be recorded

**Don't make subagent phases too large**
Break complex work into focused chunks

**Don't forget to run tests**
Always ensure subagents run tests for their work

## Example Coordination Session

```markdown
1. User: "Continue building the API"

2. You (Main Agent):
   - Read wip/scratchpad.md
   - See: Phase 3 completed (user endpoints done)
   - See: Phase 4 next (product endpoints)

3. You:
   - Launch subagent for Phase 4
   - "Implement product CRUD endpoints in src/routes/products.js"

4. Subagent:
   - Implements endpoints
   - Writes tests
   - Reports completion

5. You:
   - Update scratchpad
   - Mark Phase 4 complete
   - Add timestamp
   - List files: src/routes/products.js, tests/products.test.js
   - Update next step: Phase 5 (order endpoints)

6. You to user:
   - "Phase 4 complete. Product endpoints implemented and tested."
   - "Next: Phase 5 - Order management endpoints"
```

This is your role as coordinator. Keep the workflow moving, track everything, delegate effectively.
